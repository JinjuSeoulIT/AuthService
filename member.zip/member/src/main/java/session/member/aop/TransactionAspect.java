package session.member.aop;

public class TransactionAspect {
}
