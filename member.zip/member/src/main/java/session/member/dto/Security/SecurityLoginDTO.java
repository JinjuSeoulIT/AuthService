package session.member.dto.Security;

import lombok.AllArgsConstructor;
import lombok.Getter;



////  ℹ️ 시큐리터 DTO
//시큐리터 식별아이디 보내기용 (SecurityContext)
@Getter
@AllArgsConstructor
public class SecurityLoginDTO implements java.io.Serializable{
    private Long userId;
    private String loginId;
}