package session.member.dto.membership.Request;

//상세 입력용
import lombok.Data;

import java.time.LocalDate;

@Data

public class AuthenticationRequestDTO {
//    private long authenticationId; // // ❌ DB PK식별자
//    private long userId;           // // ❌ DB FK식별자
    private String realName;
    private String phone;
    private String email;
    private LocalDate birthDate;
    private String sex;
    private String zipCode;
    private String address1;
    private String address2;
    private String nationCode;
}