package session.member.dto.membership.Response;


//출력용 (프론트)//
import lombok.Data;

import java.time.LocalDate;

@Data
public class AuthenticationResponseDTO {


    private long authenticationId;
    private long userId;
    private String realName;
    private String phone;
    private String email;
    private LocalDate birthDate;
    private String sex;
    private String zipCode;
    private String address1;
    private String address2;
    private String nationCode;
}