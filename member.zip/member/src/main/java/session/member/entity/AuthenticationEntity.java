package session.member.entity;


import jakarta.persistence.*;
import lombok.*;


import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "member_authentication")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class AuthenticationEntity {

//    @Id
//    @GeneratedValue
//            (strategy = GenerationType.IDENTITY)
    //원래 들어가야함 트리거 추출용
    //백엔드에서 만드는것보다 DB에서 만드는게 좋음
//    동시성: 여러 요청이 동시에 와도 중복 없이 안전하게 발급
//    무결성: PK 생성이 한 곳(DB)에서 일어나서 일관됨
//    운영/마이그레이션: 데이터 이관/복구할 때도 기준이 명확함
  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE,
                  generator = "member_auth_seq_gen")  //시퀀스 참조
  @SequenceGenerator(
          name = "member_auth_seq_gen",  //시퀀스
          sequenceName = "MEMBER_auth_SEQ",
          allocationSize = 1  //호출용 1단위 1,2,3,4,5 이런식 (동시가입방지)
  )


  @Column(name = "authentication_id") //pk
  private Long authenticationId;



  @Column(name = "real_name")
  private String realName;

  @Column(name = "phone")
  private String phone;

  @Column(name = "email")
  private String email;

  @Column(name = "birth_date")
  private LocalDate birthDate;

  @Column(name = "sex")
  private String sex;

  @Column(name = "zip_code")
  private String zipCode;

  @Column(name = "address1")
  private String address1;

  @Column(name = "address2")
  private String address2;

  @Column(name = "nation_code")
  private String nationCode;





  //조인 지금 FK (회원상세 여기가 FK주인)
  @OneToOne(optional = false) // ✅ 회원삭제시 참조 아이디도 삭제
//cascade(전파) 설정이 “같이 저장/삭제”를 결정


  @JoinColumn(name = "user_id" ,nullable = false, unique = true)

  private UserEntity user;

}
