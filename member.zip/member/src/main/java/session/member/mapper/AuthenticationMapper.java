package session.member.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Mapper;

import session.member.dto.membership.Response.AuthenticationResponseDTO;

@Mapper
public interface AuthenticationMapper {

    /** userId로 상세 조회(회원 상세 페이지용)
     * 그외에  추가랑  수정도 여기에서 확인하고 응용가능
     * */
    AuthenticationResponseDTO selectAuthenticationById(@Param("userId") long userId);

}
