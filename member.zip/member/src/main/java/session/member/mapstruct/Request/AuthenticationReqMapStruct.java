package session.member.mapstruct.Request;


import common.mapper.EntityReqMapper;
import org.mapstruct.*;
import session.member.dto.membership.Request.AuthenticationRequestDTO;
import session.member.entity.AuthenticationEntity;

//맵 스트립터 입력용
@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface AuthenticationReqMapStruct extends EntityReqMapper<AuthenticationEntity, AuthenticationRequestDTO>
{

    // ✅ 가입용 (이미 쓰고 있는 것)
    AuthenticationEntity toEntity(AuthenticationRequestDTO dto);


    //수정 메서드 규칙 (입력) (부분수정용)
    //DTO에 값이 들어온 필드만 엔터티에 덮어쓰고, DTO에서 null인 필드는 기존 엔터티 값을 유지하게 만드는 패턴.
@Override
@BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
//**DTO 필드가 null이면 매핑을 “무시”**함
//그래서 entity의 기존 값이 안 날아감

@Mapping(target = "authenticationId", ignore = true) // PK는 수정하면 안 되니까 절대 건드리지 말라는 규칙
@Mapping(target =  "user", ignore = true)            // PK는 수정하면 안 되니까 절대 건드리지 말라는 규칙

// ✅ 수정용 추가 (덮어씌우기 ) 엔터티-> dto (상세)auth만 지금 해놓은상태
void updateEntity(AuthenticationRequestDTO dto, @MappingTarget AuthenticationEntity entity);

}
