package session.member.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import session.member.entity.AuthenticationEntity;

import java.util.Optional;


//DB랑 직접 대화하는 담당(DAO)
public interface AuthenticationRepository extends JpaRepository<AuthenticationEntity,Long> {

    AuthenticationEntity findOneByUser_UserId(Long userId);//이게 프론트pk참조형


//    save(entity) : INSERT/UPDATE
//
//    findById(id) : PK로 조회
//
//    findAll() : 전체 조회
//
//    deleteById(id) : 삭제
//
//    count() : 전체 개수
    //상속
//1:1에서 FK 가진 쪽(지금은 AuthenticationEntity)이 ‘주인’이고, FK는 주인 쪽 set을 해야 DB에 들어간다.




}











