package session.member.service;

import session.member.dto.login.LoginRequestDTO;
import session.member.dto.login.LoginResponseDTO;
import session.member.dto.membership.Request.AuthenticationRequestDTO;
import session.member.dto.membership.Request.UserRequestDTO;
import session.member.dto.membership.Response.AuthenticationResponseDTO;
import session.member.dto.membership.Response.UserResponseDTO;



public interface UserService {





    /**
     * ✅ 로그인 유스케이스(컨트롤러가 호출)
     * - loginId로 passwordHash 조회
     * - matches() 검증
     * - 응답 DTO 구성
     */
    LoginResponseDTO login(LoginRequestDTO loginReq);

    /**
     * ✅ 회원가입 유스케이스(컨트롤러가 호출)
     //  * - 중복체크(조회=MyBatis)
     //  * - 비번 해시(SecurityService)
     //  * - 저장(쓰기=JPA)
     //  * - 응답 DTO 구성
     */
    UserResponseDTO signup(UserRequestDTO userReq,
                            AuthenticationRequestDTO authReq);



     //✅ 회원 상세 조회(출력용)
    AuthenticationResponseDTO selectAuthenticationById(long userId);



     //✅ 회원수정
    AuthenticationResponseDTO updateAuthentication(Long userId, AuthenticationRequestDTO authReq);



     //✅ 회원 삭제 조회및 통합
    UserResponseDTO deleteUserAndReturn(long userId);
}