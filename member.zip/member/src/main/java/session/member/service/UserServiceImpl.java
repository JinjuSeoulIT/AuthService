package session.member.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import session.member.dto.login.LoginRequestDTO;
import session.member.dto.login.LoginResponseDTO;
import session.member.dto.login.LoginRowDTO;
import session.member.dto.membership.Request.AuthenticationRequestDTO;
import session.member.dto.membership.Request.UserRequestDTO;
import session.member.dto.membership.Response.AuthenticationResponseDTO;
import session.member.dto.membership.Response.UserResponseDTO;
import session.member.mapper.AuthenticationMapper;
import session.member.mapper.UserMapper;
import session.member.service.JpaService.JpaUserService;
import session.member.service.SecurityService.SecurityService;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;                     // ✅유저 조회(MyBatis)
    private final SecurityService securityService;            // ✅ 해시/검증

    private final JpaUserService jpaUserService;              // ✅ 쓰기(JPA)
    private final AuthenticationMapper authenticationMapper;  // ✅상세 조회(MyBatis)

    //로그인 조회 (검증)
    @Override
    public LoginResponseDTO login(LoginRequestDTO loginReq) {

        // 1) loginId로 유저 row 조회 (userId, loginId, passwordHash, loginType)
        LoginRowDTO row = userMapper.selectLoginRowByLoginId(loginReq.getLoginId());
        if (row == null) {
            return null;
        }
        // 2) 비밀번호 검증 (encode X, matches O)
        boolean ok = securityService.matches(loginReq.getPassword(), row.getPasswordHash());
        if (!ok) {
            return null;
        }
        // 3) 응답 DTO
        LoginResponseDTO res = new LoginResponseDTO();
        res.setUserId(row.getUserId());
        res.setLoginId(row.getLoginId());
        return res;
    }



    //**오케스트레이션 **/
//  * - 중복체크(조회=MyBatis)
//  * - 비번 해시(SecurityService)
//  * - 저장(쓰기=JPA)
//  * - 응답 DTO 구성
    //회원추가 조회
    @Override
    @Transactional
    public UserResponseDTO signup(UserRequestDTO userReq,
                                  AuthenticationRequestDTO authReq) {
        // ✅ 중복 체크는 서비스에서
        if (userMapper.countByLoginId(userReq.getLoginId()) > 0) return null;

        String hash = securityService.encode(userReq.getPassword());                   //인증서비스 비번해시처리
        Long userId = jpaUserService.signupWithAuthentication(userReq, authReq, hash); //jpa서비스  ID/PW 처리

        UserResponseDTO dto = new UserResponseDTO();
        dto.setUserId(userId);
        dto.setLoginId(userReq.getLoginId());
        return dto;
    }






    //상세 조회
    @Override
    public AuthenticationResponseDTO selectAuthenticationById ( long userId)
    {return authenticationMapper.selectAuthenticationById(userId);
    }




    //수정 조회
    @Transactional
    @Override
    public AuthenticationResponseDTO updateAuthentication(Long userId, AuthenticationRequestDTO authReq)
    {    // 1) 쓰기 = JPA
        jpaUserService.updateAuthentication(userId, authReq);
        // 2) 응답(조회) = MyBatis
        AuthenticationResponseDTO dto = authenticationMapper.selectAuthenticationById(userId);
        if (dto == null) throw new RuntimeException("수정 후 조회 실패");

        return authenticationMapper.selectAuthenticationById(userId);
    }




    //삭제 조회
    //삭제는 따로 레지스파토리를 이용하지않는건 응답처리를 위해서
    @Override
    @Transactional
    public UserResponseDTO deleteUserAndReturn(long userId) {
        // 0) (응답/존재확인용) MyBatis로 먼저 조회
        UserResponseDTO before = userMapper.selectUserById(userId);
        if (before == null) {   return null;    }  // 또는 NotFound 예외
        // 1) JPA로 삭제 (자식 -> 부모)
        jpaUserService.deleteUser(userId);
        // 2) 삭제 결과로 “삭제된 사용자 정보”를 돌려주기
        //    (삭제 후엔 DB에 없으니 before를 반환해야 함)
        return before;
    }
    }